function [u] = controller(qd, waypts, t, params)
% CONTROLLER robot controller
%
% INPUTS:
% qd     - qd structure, contains current state
% waypts - 2 x n, way points [x; y]
% t      - 1 x 1, time
% params - struct, output from turtlebot3() and whatever parameters you want to pass in
%
% OUTPUTS:
% u      - 2 x 1, wheel velocities [left, right]

% =================== Your code goes here ===================
%find lookahead point
radius = params.radius;
margin = 1;
lookahead = margin + radius;


pose = transpose(qd.pos);

[pt_min, dist_min] = find_closest_point(pose, waypts);

%now that we have the closet point,we must find the goal point




%[proj, dist_min] = find_closest_point(pose, waypts,segment)



% =================== Your code ends here ===================


end
